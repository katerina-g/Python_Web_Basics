from django.apps import AppConfig


class RetakeExamConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'retake.retake_exam'
