from django.apps import AppConfig


class RecipesAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'recipes.recipes_app'
